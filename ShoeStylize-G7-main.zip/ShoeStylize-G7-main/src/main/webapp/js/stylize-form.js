$(document).ready(e => {
    let data = [];
    let $s2Nodes = $('.s2-nodes');

    let refresh = () => {
        $s2Nodes.empty()
        data.forEach(d => {
            let $node = $(`
                            <div class="s2-node">
                                <image class="s2-node--image" src="${d.image_link}">
                                <div class="s2-node--meta">
                                    <p class="s2-node--title">${d.title}</p>
                                    <p class="s2-node--desc">${d.description}</p>
                                </div>
                                <div class="s2-node--btn"></div>
                            </div>
                        `);

            if (!d.selected) {
                $node.find('.s2-node--btn').append(`<button type="button" class="btn btn-secondary s2-btn--add">Add to my shoe</button>`);
            } else {
                $node.find('.s2-node--btn').append(`<button type="button" class="btn btn-success s2-btn--add">Added</button>`);
            }
            $s2Nodes.append($node);
            $node.find('.s2-btn--add').click(c => {
                d.selected = !d.selected;
                refresh();
            });
        });
    };

    aget(`./api/shoe-extra/list`, {}, s => {
        s.forEach(d => {
            d.selected = false;
            data.push(d);
        });
        refresh();
    });

    $('#btn-back').click(c => {
        apost('./api/stylize-form/back', {}, s => {
            window.location.reload();
        })
    })

    $('#btn-submit').click(c => {
        apost('./api/stylize-form', {
            items: data.filter(d => d.selected)
        }, s => {
            window.location.reload();
        })
    })
});