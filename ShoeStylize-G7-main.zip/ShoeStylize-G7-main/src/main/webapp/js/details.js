$(document).ready((e) => {
    $("#i--share").click(function () {
        var textToCopy = window.location.href;
        var tempInput = $("<input>");
        $("body").append(tempInput);
        tempInput.val(textToCopy).select();
        document.execCommand("copy");
        tempInput.remove();
        $('#i--share-noti').html('URL copied to clipboard')
        setTimeout(() => {
            $('#i--share-noti').html('')
        }, 3500)

    });
});