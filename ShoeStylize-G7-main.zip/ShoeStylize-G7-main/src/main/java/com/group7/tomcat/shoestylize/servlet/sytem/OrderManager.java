package com.group7.tomcat.shoestylize.servlet.sytem;

import com.group7.tomcat.shoestylize.servlet.database.DBContext;
import com.group7.tomcat.shoestylize.servlet.database.DBObject;
import com.group7.tomcat.shoestylize.servlet.entity.*;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class OrderManager {

    private static OrderManager instance;

    public void assignBill(HttpSession session) {
        if (session.getAttribute("bill") == null) {
            session.setAttribute("bill", new PendingBill(session));
        }
    }

    public PendingBill getBill(HttpSession session) {
        assignBill(session);
        return (PendingBill) session.getAttribute("bill");
    }

    public boolean submitOrder(PendingBill bill) {
        if (bill == null) {
            return false;
        }

        List<PendingOrder> orderList = bill.getOrders();
        if (orderList.isEmpty()) {
            return false;
        }

        List<DBObject> result = DBContext.executeQuery("INSERT INTO [Bill] (author_id) OUTPUT INSERTED.id VALUES (?)", bill.getAuthor().getId());
        if (!result.isEmpty()) {
            int createdId = result.get(0).getInt("id");

            System.out.println(orderList.size());

            for (PendingOrder order : orderList) {
                List<DBObject> resultOrder;
                if (order.getImage() == null) {

                    resultOrder = DBContext.executeQuery("INSERT INTO [Order_Shoe]("
                            + "shoe_id, bill_id, address, phone1, phone2, "
                            + "size_id, style_note, order_note, total_price, order_shoe_type) "
                            + "OUTPUT INSERTED.id VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                            order.getShoeId(),
                            createdId,
                            order.getAddress(),
                            order.getPhone1(),
                            order.getPhone2(),
                            order.getSizeId(),
                            order.getStyleNote(),
                            order.getOrderNote(),
                            order.getTotalPrice(),
                            order.getOrderType()
                    );
                } else {
                    resultOrder = DBContext.executeQuery("INSERT INTO [Order_Shoe]("
                            + "shoe_id, image_link, bill_id, address, phone1, phone2, "
                            + "size_id, style_note, order_note, total_price, order_shoe_type) "
                            + "OUTPUT INSERTED.id VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                            order.getShoeId(),
                            order.getImage(),
                            createdId,
                            order.getAddress(),
                            order.getPhone1(),
                            order.getPhone2(),
                            order.getSizeId(),
                            order.getStyleNote(),
                            order.getOrderNote(),
                            order.getTotalPrice(),
                            order.getOrderType()
                    );
                }

                int createdOrderId = resultOrder.get(0).getInt("id");
                for (ShoeExtra extra : order.getExtras()) {
                    DBContext.executeUpdate("INSERT INTO [Order_Shoe_Extra](shoe_extra_id, order_shoe_id) VALUES (?, ?)",
                            extra.getId(), createdOrderId);
                }
            }
            bill.getOrders().clear();
            return true;
        }
        return false;
    }

    public List<Bill> obtainPendingOrders(HttpSession session) {
        Account acc = (Account) session.getAttribute("user");
        if (acc == null) {
            return new ArrayList<>();
        }

        List<DBObject> dbObjs = DBContext.executeQuery("SELECT * FROM [Bill] WHERE author_id=?", acc.getId());
        return dbObjs.stream().map(Bill::new).collect(Collectors.toList());
    }

    public List<Order> getSPUnassignedOrders() {
        List<DBObject> result = DBContext.executeQuery(
                "SELECT os.*, s.title, s.price, ss.size_name, s.image_link, s.id AS shoe_id, s.image_link AS preview_link, u.username FROM [Order_Shoe] os "
                + "INNER JOIN [Shoe] s ON os.shoe_id = s.id "
                + "INNER JOIN [Shoe_Size] ss ON os.size_id = ss.id "
                + "INNER JOIN [Bill] b ON os.bill_id = b.id "
                + "INNER JOIN [User] u ON b.author_id = u.id "
                + "WHERE os.order_shoe_status='pending'"
        );
        return result.stream().map(p -> new Order(p)).collect(Collectors.toList());
    }

    public List<Order> getSPAssignedOrders(HttpSession session) {
        Account acc = (Account) session.getAttribute("user");
        if (acc == null) {
            return new ArrayList<>();
        }

        List<DBObject> result = DBContext.executeQuery(
                "SELECT os.*, s.title, s.price, ss.size_name, s.image_link, s.id AS shoe_id, s.image_link AS preview_link, u.username FROM [Order_Shoe] os "
                + "INNER JOIN [Shoe] s ON os.shoe_id = s.id "
                + "INNER JOIN [Shoe_Size] ss ON os.size_id = ss.id "
                + "INNER JOIN [Bill] b ON os.bill_id = b.id "
                + "INNER JOIN [User] u ON b.author_id = u.id "
                + "WHERE os.order_shoe_status='in_progress' AND os.service_provider_id=?",
                acc.getId());
        return result.stream().map(p -> new Order(p)).collect(Collectors.toList());
    }

    public List<Order> getSPSuccessOrders(HttpSession session) {
        Account acc = (Account) session.getAttribute("user");
        if (acc == null) {
            return new ArrayList<>();
        }

        List<DBObject> result = DBContext.executeQuery(
                "SELECT os.*, s.title, s.price, ss.size_name, s.image_link, s.id AS shoe_id, s.image_link AS preview_link, u.username FROM [Order_Shoe] os "
                + "INNER JOIN [Shoe] s ON os.shoe_id = s.id "
                + "INNER JOIN [Shoe_Size] ss ON os.size_id = ss.id "
                + "INNER JOIN [Bill] b ON os.bill_id = b.id "
                + "INNER JOIN [User] u ON b.author_id = u.id "
                + "WHERE os.order_shoe_status='success' AND os.service_provider_id=?",
                acc.getId());
        return result.stream().map(p -> new Order(p)).collect(Collectors.toList());
    }

    public Order getOrderById(int id) {
        List<DBObject> result = DBContext.executeQuery(
                "SELECT * FROM [Order_Shoe] WHERE id=?",
                id);

        if (result.isEmpty()) {
            return null;
        }

        return new Order(result.get(0));
    }

    public static OrderManager get() {
        if (instance == null) {
            instance = new OrderManager();
        }
        return instance;
    }
}
