package com.group7.tomcat.shoestylize.servlet.controller.api;

import com.group7.tomcat.shoestylize.servlet.entity.Shoe;
import com.group7.tomcat.shoestylize.servlet.entity.ShoeExtra;
import com.group7.tomcat.shoestylize.servlet.sytem.OrderManager;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpSession;

@WebServlet(name = "stylize-form-out", urlPatterns = {"/stylize-form/out"})
public class StylizeFormOutServlet extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json");
        HttpSession session = request.getSession();

        if (session.getAttribute("user") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        Shoe shoe = (Shoe) session.getAttribute("Shoe");
        if (shoe == null) {
            response.sendRedirect(request.getContextPath() + "/404");
            return;
        }

        try {
            int shoeId = shoe.getId();
            String styleNote = (String) session.getAttribute("PendingOrder_StyleNote");
            String orderType = (String) session.getAttribute("PendingOrder_OrderType");
            InputStream stream = (InputStream) session.getAttribute("PendingOrder_Image");
            String address = request.getParameter("address");
            String phone1 = request.getParameter("phone1");
            String phone2 = request.getParameter("phone2");
            String sizeIdStr = request.getParameter("shoe-size");
            String orderNote = request.getParameter("note");

            List<ShoeExtra> extras = new ArrayList<>();
            try {
                extras = (List<ShoeExtra>) session.getAttribute("StylizeForm_Extras");
            } catch (Exception e) {}
           
            int sizeId = Integer.parseInt(sizeIdStr);
            
            if (stream == null) {
                OrderManager.get().getBill(session).addOrder(shoeId,
                    styleNote,
                    orderType,
                    address,
                    phone1,
                    phone2,
                    sizeId,
                    orderNote,
                    extras);
            } else {
                OrderManager.get().getBill(session).addOrder(shoeId,
                    stream,
                    styleNote,
                    orderType,
                    address,
                    phone1,
                    phone2,
                    sizeId,
                    orderNote,
                    extras);
            }

            
            response.sendRedirect(request.getContextPath() + "/carts");
        } catch (Exception e) {
            response.sendRedirect(request.getContextPath() + "/404");
        }

    }
}
