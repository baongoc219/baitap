package com.group7.tomcat.shoestylize.servlet.entity;

import com.group7.tomcat.shoestylize.servlet.database.DBContext;
import com.group7.tomcat.shoestylize.servlet.database.DBObject;
import com.group7.tomcat.shoestylize.servlet.sytem.ShoeExtraManager;
import java.text.DecimalFormat;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Order {

    private final int id;
    private final String imageLink;
    private final int billId;
    private final String address;
    private final String phone1;
    private final String phone2;
    private final String orderType;
    private final String status;
    private final int serviceProviderId;
    private final String title;
    private final double totalPrice;
    private final String styleNote;
    private final String orderNote;
    private final int sizeId;
    private final String orderPaymentMethod;
    private final double price;
    private final String sizeName;
    private List<ShoeExtra> extras;
    private final String previewLink;
    private final int shoeId;
    private final String username;
    private final DBObject obj;

    public Order(DBObject obj) {
        this.obj = obj;
        this.extras = new ArrayList<>();
        this.id = obj.getInt("id");
        this.title = obj.getString("title");
        this.price = obj.getDouble("price");
        this.imageLink = obj.getString("image_link");
        this.billId = obj.getInt("bill_id");
        this.address = obj.getString("address");
        this.phone1 = obj.getString("phone1");
        this.phone2 = obj.getString("phone2");
        this.styleNote = obj.getString("style_note");
        this.orderNote = obj.getString("order_note");
        this.totalPrice = obj.getDouble("total_price");
        this.orderType = obj.getString("order_shoe_type");
        this.sizeId = obj.getInt("size_id");
        this.status = obj.getString("order_shoe_status");
        this.orderPaymentMethod = obj.getString("order_payment_method");
        this.serviceProviderId = obj.getInt("service_provider_id");
        this.sizeName = obj.getString("size_name");
        this.previewLink = obj.getString("preview_link");
        this.shoeId = obj.getInt("shoe_id");
        this.username = obj.getString("username");

        System.out.println(username);
        List<DBObject> extraObj = DBContext.executeQuery("SELECT * FROM [Order_Shoe_Extra] WHERE order_shoe_id=?", id);
        extras = extraObj.stream().map(p -> ShoeExtraManager.getShoeExtra(p.getInt("shoe_extra_id"))).collect(Collectors.toList());
    }

    public int getId() {
        return id;
    }
    
    public String getUsername() {
        return username;
    }
    
    public int getShoeId() {
        return shoeId;
    }

    public String getImageLink() {
        return imageLink;
    }
    
    public byte[] getImageLinkBytes() {
        return obj.getBytes("image_link");
    }
    
    public String getPreviewLink() {
        return previewLink;
    }

    public int getBillId() {
        return billId;
    }

    public double getPrice() {
        double formattedPrice = Double.parseDouble(new DecimalFormat("0.00").format(price));
        return formattedPrice;
    }

    public String getAddress() {
        return address;
    }

    public String getPhone1() {
        return phone1;
    }

    public String getPhone2() {
        return phone2;
    }

    public String getOrderType() {
        return orderType;
    }

    public String getStatus() {
        return status;
    }

    public int getServiceProviderId() {
        return serviceProviderId;
    }

    public String getTitle() {
        return title;
    }

    public double getTotalPrice() {
        double formattedPrice = Double.parseDouble(new DecimalFormat("0.00").format(totalPrice));
        return formattedPrice;
    }

    public String getStyleNote() {
        return styleNote;
    }

    public String getOrderNote() {
        return orderNote;
    }

    public int getSizeId() {
        return sizeId;
    }

    public String getOrderPaymentMethod() {
        return orderPaymentMethod;
    }

    public List<ShoeExtra> getExtras() {
        return extras;
    }

    public String getSizeName() {
        return sizeName;
    }
}
