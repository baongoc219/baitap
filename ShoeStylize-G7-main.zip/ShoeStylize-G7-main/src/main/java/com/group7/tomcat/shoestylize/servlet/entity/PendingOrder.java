package com.group7.tomcat.shoestylize.servlet.entity;

import com.group7.tomcat.shoestylize.servlet.database.DBContext;
import com.group7.tomcat.shoestylize.servlet.database.DBObject;
import com.group7.tomcat.shoestylize.servlet.sytem.ShoeManager;
import com.group7.tomcat.shoestylize.servlet.utils.IDUtils;
import java.io.InputStream;
import java.text.DecimalFormat;

import java.util.List;

public class PendingOrder {

    private final String uuid;
    private InputStream stream = null;
    private final String styleNote;
    private final String orderType;
    private final String address;
    private final String phone1;
    private final String phone2;
    private final int sizeId;
    private final String orderNote;
    private DBObject dbObject;
    private String shoeType;
    private final int shoeId;
    private final List<ShoeExtra> extras;
    private String imageLink;

    public PendingOrder(int shoeId, String styleNote, String orderType, String address, String phone1, String phone2, int sizeId, String orderNote, List<ShoeExtra> extras) {
        this(shoeId, null, styleNote, orderType, address, phone1, phone2, sizeId, orderNote, extras);
    }

    public PendingOrder(int shoeId, InputStream stream, String styleNote, String orderType, String address, String phone1, String phone2, int sizeId, String orderNote, List<ShoeExtra> extras) {
        this.shoeId = shoeId;
        this.uuid = IDUtils.generateUUID();

        List<DBObject> dbobjs = DBContext.executeQuery("SELECT * FROM [Shoe] WHERE id=?", shoeId);
        if (!dbobjs.isEmpty()) {
            dbObject = dbobjs.get(0);
            this.shoeType = dbObject.getString("shoe_type");
            this.imageLink = dbObject.getString("image_link");
        }

        this.stream = stream;
        this.styleNote = styleNote;
        this.orderType = orderType;
        this.address = address;
        this.phone1 = phone1;
        this.phone2 = phone2;
        this.sizeId = sizeId;
        this.orderNote = orderNote;
        this.extras = extras;
    }

    public String getUUID() {
        return uuid;
    }

    public String getTitle() {
        return dbObject.getString("title");
    }
    
    public String getImageLink() {
        return imageLink;
    }

    public double getPrice() {
        double formattedPrice = Double.parseDouble(new DecimalFormat("0.00").format(dbObject.getDouble("price")));
        return formattedPrice;
    }

    public String getStyleNote() {
        if (styleNote == null || styleNote.isEmpty() || styleNote.trim().isEmpty()) {
            return "No description provided.";
        }
        return styleNote;
    }

    public String getOrderType() {
        return orderType;
    }

    public String getAddress() {
        return address;
    }

    public String getPhone1() {
        return phone1;
    }

    public String getPhone2() {
        return phone2;
    }

    public int getSizeId() {
        return sizeId;
    }

    public String getSizeName() {
        return ShoeManager.getSizeFromId(getSizeId());
    }

    public String getOrderNote() {
        return orderNote;
    }

    public DBObject getDbObject() {
        return dbObject;
    }

    public String getShoeType() {
        return shoeType;
    }

    public int getShoeId() {
        return shoeId;
    }

    public List<ShoeExtra> getExtras() {
        return extras;
    }

    public double getTotalPrice() {
        double basePrice = getPrice();
        for (ShoeExtra extra : getExtras()) {
            basePrice += extra.getPrice();
        }
        double formattedPrice = Double.parseDouble(new DecimalFormat("0.00").format(basePrice));
        return formattedPrice;
    }
    
    public InputStream getImage() {
        return stream;
    }

}
