package com.group7.tomcat.shoestylize.servlet.sytem;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

public class GsonBuilder {

    private JsonObject jsonObject;

    public GsonBuilder() {
        jsonObject = new JsonObject();
    }

    public GsonBuilder set(String key, String value) {
        jsonObject.addProperty(key, value);
        return this;
    }

    public GsonBuilder set(String key, int value) {
        jsonObject.addProperty(key, value);
        return this;
    }

    public GsonBuilder set(String key, double value) {
        jsonObject.addProperty(key, value);
        return this;
    }

    public GsonBuilder set(String key, boolean value) {
        jsonObject.addProperty(key, value);
        return this;
    }

    public String build() {
        Gson gson = new Gson();
        return gson.toJson(jsonObject);
    }
    
    public JsonObject buildJson() {
        return jsonObject;
    }

}
