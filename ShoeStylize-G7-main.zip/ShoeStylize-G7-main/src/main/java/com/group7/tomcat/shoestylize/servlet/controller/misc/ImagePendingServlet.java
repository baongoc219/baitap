package com.group7.tomcat.shoestylize.servlet.controller.misc;

import com.group7.tomcat.shoestylize.servlet.entity.Order;
import com.group7.tomcat.shoestylize.servlet.sytem.OrderManager;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Base64;

@WebServlet(name = "image-pending-order", urlPatterns = {"/image/order-pending/:id"})
public class ImagePendingServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("image/jpeg");
        HttpSession session = request.getSession();

        if (session.getAttribute("user") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String idStr = request.getParameter("id");
        if (idStr == null) {

        } else {
            try {
                int id = Integer.parseInt(idStr);
            } catch (NumberFormatException e) {

            }

            Order order = OrderManager.get().getOrderById(0);
            String base64Image = Base64.getEncoder().encodeToString(order.getImageLink().getBytes());

            byte[] imageBytes = Base64.getDecoder().decode(base64Image);
            response.getOutputStream().write(imageBytes);
        }

    }
}
