package com.group7.tomcat.shoestylize.servlet.controller.api;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.group7.tomcat.shoestylize.servlet.entity.ShoeExtra;
import com.group7.tomcat.shoestylize.servlet.sytem.ShoeExtraManager;
import com.group7.tomcat.shoestylize.servlet.utils.JsonUtils;
import com.group7.tomcat.shoestylize.servlet.entity.Shoe;
import com.group7.tomcat.shoestylize.servlet.sytem.GsonBuilder;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

@WebServlet(name = "api-stylize-form", urlPatterns = {"/api/stylize-form"})
@MultipartConfig(fileSizeThreshold = 1024 * 1024,
        maxFileSize = 1024 * 1024 * 5,
        maxRequestSize = 1024 * 1024 * 50)
public class APIStylizeFormServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        HttpSession session = request.getSession();

        if (session.getAttribute("user") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        Shoe shoe = (Shoe) session.getAttribute("Shoe");
        if (shoe == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        try {
            if (session.getAttribute("StylizeForm_Step") == null) {
                response.sendRedirect(request.getContextPath() + "/login");
                return;
            }

            int step = (int) session.getAttribute("StylizeForm_Step");
            if (step == 0) {
                String styleNote = request.getParameter("note");
                String type = request.getParameter("type");
                Part filePart = request.getPart("image");

                if (type == null || !type.equals("out") && !type.equals("in")) {
                    response.sendRedirect(request.getContextPath() + "/explore");
                    return;
                }

                session.setAttribute("PendingOrder_OrderType", type);
                session.setAttribute("PendingOrder_StyleNote", styleNote);
                session.setAttribute("StylizeForm_Step", 1);

                if (isValidImage(filePart)) {
                    session.setAttribute("PendingOrder_Image", filePart.getInputStream());
                }
                
                response.sendRedirect(request.getContextPath() + "/stylize-form?id=" + shoe.getId());

            } else if (step == 1) {
                JsonObject jsonData = JsonUtils.parseJsonRequest(request);
                JsonArray jarray = jsonData.getAsJsonArray("items");

                List<ShoeExtra> extras = new ArrayList<>();
                for (JsonElement jElement : jarray.asList()) {
                    JsonObject jobj = jElement.getAsJsonObject();
                    extras.add(ShoeExtraManager.getShoeExtra(jobj.get("id").getAsInt()));
                }

                session.setAttribute("StylizeForm_Extras", extras);
                session.setAttribute("StylizeForm_Step", 2);
                response.sendRedirect(request.getContextPath() + "/stylize-form?id=" + shoe.getId());
            }
        } catch (IOException e) {
            response.sendRedirect(request.getContextPath() + "/explore");
        }
    }

    private boolean isValidImage(Part filePart) {
        if (filePart == null) {
            return false;
        }
        String contentType = filePart.getContentType();
        return contentType != null && (contentType.equals("image/png") || contentType.equals("image/jpeg"));
    }

}
