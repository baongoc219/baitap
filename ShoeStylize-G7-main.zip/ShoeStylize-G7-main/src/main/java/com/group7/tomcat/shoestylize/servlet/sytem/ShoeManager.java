package com.group7.tomcat.shoestylize.servlet.sytem;

import com.group7.tomcat.shoestylize.servlet.database.DBContext;
import com.group7.tomcat.shoestylize.servlet.database.DBObject;
import com.group7.tomcat.shoestylize.servlet.entity.Shoe;
import java.util.ArrayList;
import java.util.List;

public class ShoeManager {
    
    public static Shoe getShoeById(int id) {
        List<DBObject> db = DBContext.executeQuery("SELECT * FROM [Shoe] WHERE id = ?", id);
        if (db.isEmpty()) {
            return null;
        }
        
        return new Shoe(db.get(0));
        
    }
    
    public static List<DBObject> getSizesFromType(String type) {
        List<DBObject> db = DBContext.executeQuery("SELECT * FROM [Shoe_Size] WHERE type_id=?", type);
        if (db.isEmpty()) {
            return new ArrayList<>();
        }
        
        return db;
    }
    
    public static String getSizeFromId(int id) {
        List<DBObject> data = DBContext.executeQuery("SELECT size_name FROM [Shoe_Size] WHERE id=?", id);
        if (data.isEmpty()) {
            return "None";
        }
        
        return data.get(0).getString("size_name");
    }
}
