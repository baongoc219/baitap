package com.group7.tomcat.shoestylize.servlet.controller.api;

import com.group7.tomcat.shoestylize.servlet.entity.Shoe;
import com.group7.tomcat.shoestylize.servlet.sytem.GsonBuilder;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "api-stylize-form-back", urlPatterns = {"/api/stylize-form/back"})
public class APIStylizeFormBackServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        HttpSession session = request.getSession();

        if (session.getAttribute("user") == null) {
            response.getWriter().println(new GsonBuilder()
                    .set("code", 403).build());
            return;
        }

        Shoe shoe = (Shoe) session.getAttribute("Shoe");
        if (shoe == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        try {
            if (session.getAttribute("StylizeForm_Step") == null) {
                response.getWriter().println(new GsonBuilder()
                        .set("code", 403).build());
                return;
            }

            int step = (int) session.getAttribute("StylizeForm_Step");
            if (step > 0) {
                session.setAttribute("StylizeForm_Step", step - 1);
                response.getWriter().println(new GsonBuilder()
                        .set("code", 200).build());
            }
        } catch (IOException e) {
            response.getWriter().println(new GsonBuilder()
                    .set("code", 403).build());
        }
    }

}
