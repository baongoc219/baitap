package com.group7.tomcat.shoestylize.servlet.controller;

import com.group7.tomcat.shoestylize.servlet.database.DBContext;
import com.group7.tomcat.shoestylize.servlet.database.DBObject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@WebServlet(name = "news", urlPatterns = {"/news"})
public class NewsServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        request.setAttribute("LIST_NEWS", listNews());
        request.getRequestDispatcher("/news.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        String title = request.getParameter("news_title");
        String content  = request.getParameter("news_content");
    
       createNews(title, content);
       response.sendRedirect("/news");
    }
    
    public void createNews(String title, String content){
        DBContext.executeUpdate("INSERT INTO News(title, content, author_id) VALUES (?,?,1)", title, content);
    }
    
    public List<DBObject> listNews() {
        List<DBObject> news = DBContext.executeQuery("SELECT * FROM News");
        SimpleDateFormat desiredDateFormat = new SimpleDateFormat("dd/MM/yyyy");

        for (DBObject newsItem : news) {
            String dateString = newsItem.getString("date_created");

            try {
                SimpleDateFormat currentDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); // Adjust this format based on your database's date format.
                Date date = currentDateFormat.parse(dateString);
                String formattedDate = desiredDateFormat.format(date);
                newsItem.setRow("date_created_f", formattedDate);
            } catch (ParseException e) {
                return new ArrayList<>();
            }
        }
        return news;
    }
}
