package com.group7.tomcat.shoestylize.servlet.controller.misc;

import com.group7.tomcat.shoestylize.servlet.entity.Order;
import com.group7.tomcat.shoestylize.servlet.sytem.OrderManager;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Base64;

@WebServlet(name = "image-order", urlPatterns = {"/image/order"})
public class ImageServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("image/png");
        HttpSession session = request.getSession();

//        if (session.getAttribute("user") == null) {
//            response.getWriter().println();
//                            System.out.println("This order does not exist 0!");
//            return;
//        }

        String idStr = request.getParameter("id");
        if (idStr == null) {
            response.getWriter().println();
                            System.out.println("This order does not exist 0.5!");
        } else {
            try {
                int id = Integer.parseInt(idStr);
                Order order = OrderManager.get().getOrderById(id);
                response.getOutputStream().write(order.getImageLinkBytes());
            } catch (NumberFormatException e) {

            }

        }

    }
}
