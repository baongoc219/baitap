package com.group7.tomcat.shoestylize.servlet.controller;

import com.group7.tomcat.shoestylize.servlet.dao.DAO;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "RegisterGoogleServlet", urlPatterns = {"/register-google"})
public class RegisterGoogleServlet extends HttpServlet {

    private final static String ROLE_CUSTOMER = "role_customer";
    private final static String ROLE_SERVICE_PROVIDER = "role_service_provider";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/register.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");
        response.setCharacterEncoding("utf-8");
        String username = request.getParameter("username");
        String fullname = request.getParameter("fullname");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String address = request.getParameter("address");
        Date dob = Date.valueOf(request.getParameter("dob"));
        String phone = request.getParameter("phone");
        String city = request.getParameter("city");
        String state = request.getParameter("state");
        String role = request.getParameter("role");
        String username_err = "", password_err = "", fullname_err = "";
        DAO dao = new DAO();
        
        boolean progressed = true;

        if (username.length() < 5 || username.length() > 32) {
            username_err = "Username must be between 5-32 characters.";
            request.setAttribute("USERNAME_ERR", username_err);
            progressed = false;
        }
        
        if (username.contains(" ")) {
            request.setAttribute("USERNAME_ERR", "Username cannot have whitespace!");
            progressed = false;
        }
        
        if (password.length() < 5 || password.length() > 40) {
            password_err = "Password must be between 5-40 characters.";
            request.setAttribute("PASSWORD_ERR", password_err);
            progressed = false;
        }
        
        if (fullname.length() < 5 || fullname.length() > 32) {
            fullname_err = "Full name must be between 5-32 characters.";
            request.setAttribute("FULLNAME_ERR", fullname_err);
            progressed = false;
        }
        
        if (dao.getUser(username) != null){
            request.setAttribute("USERNAME_EXISTED", "This username is unavailable.");
            progressed = false;
        }
        
        if (dao.isEmailExist(email) != null){
            request.setAttribute("EMAIL_EXISTED", "This email has already been used.");
            progressed = false;
        }
        
        request.setAttribute("USERNAME", username);
        request.setAttribute("FULLNAME", fullname);
        request.setAttribute("EMAIL", email);
        request.setAttribute("PASSWORD", password);
        request.setAttribute("ADDRESS", address);
        request.setAttribute("DOB", dob);
        request.setAttribute("PHONE", phone);
        request.setAttribute("CITY", city);
        request.setAttribute("ROLE", role);
        
        try {
            if (progressed) {
                if (role.equals(ROLE_CUSTOMER)) {
                    dao.signup(username, fullname, email, password, address, dob, phone, city, state, "customer", "google");
                    request.setAttribute("SUCCESS_CUS", "Sign up successfully with role CUSTOMER");
                }
                if (role.equals(ROLE_SERVICE_PROVIDER)) {
                    dao.signup(username, fullname, email, password, address, dob, phone, city, state, "service_provider", "google");
                    request.setAttribute("SUCCESS_PROV", "Sign up successfully with role SERVICE PROVIDER");
                }
                request.getRequestDispatcher("/register_google.jsp").forward(request, response);
                return;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        request.getRequestDispatcher("/register.jsp").forward(request, response);
    }
}
