package com.group7.tomcat.shoestylize.servlet.controller;

import com.group7.tomcat.shoestylize.servlet.database.DBContext;
import com.group7.tomcat.shoestylize.servlet.database.DBObject;
import com.group7.tomcat.shoestylize.servlet.entity.Account;
import com.group7.tomcat.shoestylize.servlet.entity.SPStatus;
import com.group7.tomcat.shoestylize.servlet.sytem.OrderManager;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import javax.servlet.http.HttpSession;

@WebServlet(name = "sp-orders", urlPatterns = {"/sp/orders"})
public class SPOrderServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        
        Account acc = (Account) session.getAttribute("user");
        if (acc == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        List<DBObject> dbObj = DBContext.executeQuery(
                "SELECT COUNT(*) AS total_orders, "
                        + "SUM(CASE WHEN order_shoe_status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled, "
                        + "SUM(CASE WHEN order_shoe_status = 'success' THEN 1 ELSE 0 END) AS success, "
                        + "SUM(CASE WHEN order_shoe_status = 'in_progress' THEN 1 ELSE 0 END) AS in_progress, "
                        + "SUM(CASE WHEN order_shoe_status = 'success' THEN total_price ELSE 0 END) AS total_earn "
                        + "FROM Order_Shoe WHERE service_provider_id=?"
                , acc.getId());
        
        if (!dbObj.isEmpty()) {
            request.setAttribute("STATS", new SPStatus(dbObj.get(0)));
        }

        request.setAttribute("LIST_UNFINISHED_ORDERS", OrderManager.get().getSPUnassignedOrders());
        request.setAttribute("LIST_ASSIGNED_ORDERS", OrderManager.get().getSPAssignedOrders(session));
        request.setAttribute("LIST_FINISHED_ORDERS", OrderManager.get().getSPSuccessOrders(session));
        request.getRequestDispatcher("/sp_orders.jsp").forward(request, response);
    }
}
