package com.group7.tomcat.shoestylize.servlet.controller.api;

import com.group7.tomcat.shoestylize.servlet.database.DBContext;
import com.group7.tomcat.shoestylize.servlet.entity.Account;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet(name = "api-sp-assign", urlPatterns = {"/api/sp/assign"})
public class APIServiceProviderAssign extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        HttpSession session = request.getSession();

        if (session.getAttribute("user") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        Account acc = (Account) session.getAttribute("user");

        String id = request.getParameter("id");
        if (id == null) {
            response.sendRedirect(request.getContextPath() + "/sp/orders");
            return;
        }
        try {
            int i = Integer.parseInt(id);
            DBContext.executeUpdate("UPDATE [Order_Shoe] SET service_provider_id=?, order_shoe_status=? WHERE id=?",
                    acc.getId(), "in_progress", i);
            response.sendRedirect(request.getContextPath() + "/sp/orders");
        } catch (Exception e) {
            response.sendRedirect(request.getContextPath() + "/sp/orders");
            return;
        }

    }
}
