package com.group7.tomcat.shoestylize.servlet.controller;

import com.group7.tomcat.shoestylize.servlet.dao.DAO;
import com.group7.tomcat.shoestylize.servlet.entity.Account;
import java.io.IOException;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "UserUpdateServlet", urlPatterns = {"/settings"})
public class UpdateServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession session = request.getSession();
        if (session.getAttribute("user") == null) {
            request.getRequestDispatcher("/error_403.jsp").forward(request, response);
        } else {
            request.getRequestDispatcher("/user_setting.jsp").forward(request, response);
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        HttpSession session = request.getSession();
        try {
            Account acc = (Account) session.getAttribute("user");
            if (acc == null) {
                request.getRequestDispatcher("/error_403.jsp").forward(request, response);
                return;
            }

            String fullname = request.getParameter("fullname");
            String email = request.getParameter("email");
            String address = request.getParameter("address");
            String phone = request.getParameter("contact_number");
            String state = request.getParameter("state");
            String city = request.getParameter("city");
            String confirm_password = request.getParameter("confirm_password");
            String password = acc.getPassword();
            
            System.out.println(fullname);
            
            boolean progressed = true;

            String newPassword = request.getParameter("password");
            if (newPassword != null && !newPassword.isEmpty() && !newPassword.trim().isEmpty()) {
                password = newPassword;
                if (!password.equals(confirm_password)) {
                    request.setAttribute("err_password_mismatch", "Password does not match.");
                    progressed = false;
                }
            }

            if (password.length() < 5 || password.length() > 40) {
                request.setAttribute("err_password", "Password must be between 5-40 characters.");
                progressed = false;
            }

            if (fullname.length() < 5 || fullname.length() > 32) {
                request.setAttribute("err_fullname", "Full name must be between 5-32 characters.");
                progressed = false;
            }

            DAO dao = new DAO();

            if (!acc.getEmail().equals(email) && dao.isEmailExist(email) != null) {
                request.setAttribute("err_email", "This email has already been used.");
                progressed = false;
            }

            if (progressed) {
                dao.updateAccount(fullname, email, password, address, phone, city, state, acc.getId());
                request.setAttribute("err_none", "Account has been updated.");
            }
            
            session.setAttribute("user", dao.getUser(acc.getUsername()));

            request.getRequestDispatcher("/user_setting.jsp").forward(request, response);
        } catch (Exception e) {
            request.getRequestDispatcher("/error_403.jsp").forward(request, response);
            return;
        }
    }

}
