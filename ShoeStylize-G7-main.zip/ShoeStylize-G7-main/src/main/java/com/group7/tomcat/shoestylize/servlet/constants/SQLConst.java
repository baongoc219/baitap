package com.group7.tomcat.shoestylize.servlet.constants;

public class SQLConst {

    //User
    public static final String GET_USER_BY_EMAIL = "SELECT * FROM [User] WHERE email=?";
    public static final String GET_USER_BY_USERNAME = "SELECT * FROM [User] WHERE username=?";
    public static final String GET_USER = "SELECT * FROM [User] WHERE username=? AND password=?";
    public static final String ADD_USER = "INSERT INTO [User](username, full_name, email, [password], address, date_birth, contact_number, city, state, token, role_id)"
                    + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        public static final String ADD_USER_WITH_LOGIN_METHOD = "INSERT INTO [User](username, full_name, email, [password], address, date_birth, contact_number, city, state, role_id, token, login_method)"
                    + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    public static final String UPDATE_USER = "UPDATE [User] SET "
            + "full_name=?, email=?, password=?, address=?, contact_number=?, city =?, state=? WHERE id=?";

    public static final String GET_STYLES = "SELECT TOP 20 * FROM [Service]";

}
