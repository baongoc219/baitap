﻿--USE master
--ALTER DATABASE [ShoeStylize_G7] SET SINGLE_USER WITH ROLLBACK IMMEDIATE
--DROP DATABASE [ShoeStylize_G7]
--CREATE DATABASE ShoeStylize_G7
--USE ShoeStylize_G7

CREATE TABLE [Role] (
	id VARCHAR(40) PRIMARY KEY,
	[name] VARCHAR(40) DEFAULT NULL,
	[priority] INT DEFAULT 0
)

CREATE TABLE [User_Login_Method] (
	login_method VARCHAR(20) PRIMARY KEY NOT NULL
)

INSERT INTO [User_Login_Method] VALUES ('normal'), ('google')

-- Create the User table
CREATE TABLE [User] (
    id INT IDENTITY(1,1) PRIMARY KEY,
    username NVARCHAR(40) NOT NULL,
    full_name NVARCHAR(40),
    email VARCHAR(320) UNIQUE NOT NULL,
    [password] VARCHAR(40) NOT NULL,
    [address] NVARCHAR(320),
    date_birth DATE NOT NULL,
    contact_number VARCHAR(11),
    city NVARCHAR(320),
    [state] NVARCHAR(320),
    role_id VARCHAR(40) NOT NULL,
    login_method VARCHAR(20) NOT NULL DEFAULT 'normal',
    token VARCHAR(50) NOT NULL,
    FOREIGN KEY (role_id) REFERENCES [Role](id),
    FOREIGN KEY (login_method) REFERENCES [User_Login_Method](login_method)
);

CREATE TABLE [News] (
    id INT IDENTITY(1,1) PRIMARY KEY,
    title NVARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    date_created DATETIME DEFAULT GETDATE(),
    author_id int NOT NULL,
    FOREIGN KEY (author_id) REFERENCES [User](id),
);

CREATE TABLE [Shoe_Type] (
	id VARCHAR(20) PRIMARY KEY
)

CREATE TABLE [Shoe_Size] (
    id INT PRIMARY KEY,
    size_name VARCHAR(10) NOT NULL,
    [type_id] VARCHAR(20) NOT NULL,
	FOREIGN KEY ([type_id]) REFERENCES [Shoe_Type](id)
);

CREATE TABLE [Shoe] (
    id INT IDENTITY(1,1) PRIMARY KEY,
	title NVARCHAR(750) NOT NULL,
    image_link TEXT,
    date_created DATETIME DEFAULT GETDATE(),
	[description] NVARCHAR(750),
	price float NOT NUll,
	shoe_type VARCHAR(20) NOT NULL,
	FOREIGN KEY (shoe_type) REFERENCES [Shoe_Type](id)
);

CREATE TABLE [Bill] (
    id INT IDENTITY(1,1) PRIMARY KEY,
    author_id INT NOT NULL,
	date_created DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (author_id) REFERENCES [User](id)
);

CREATE TABLE [Order_Shoe_Type] (
	id VARCHAR(20) PRIMARY KEY
)

CREATE TABLE [Order_Shoe_Status] (
	id VARCHAR(20) PRIMARY KEY
)

CREATE TABLE [Order_Payment_Method] (
	id VARCHAR(20) PRIMARY KEY
)

CREATE TABLE [Order_Shoe] (
    id INT IDENTITY(1,1) PRIMARY KEY,
    shoe_id INT NOT NULL,
    [image_link] VARBINARY(MAX),
    date_created DATETIME DEFAULT GETDATE(),
    bill_id INT NOT NULL,
    [address] NVARCHAR(500),
    phone1 VARCHAR(11),
    phone2 VARCHAR(11),
    size_id INT NOT NULL,
    style_note NVARCHAR(500),
    order_note NVARCHAR(500),
    total_price FLOAT NOT NULL DEFAULT 0,
    order_shoe_type VARCHAR(20) NOT NULL,
    order_shoe_status VARCHAR(20) DEFAULT 'pending',
    order_paid BIT DEFAULT 0 CHECK (order_paid IN (0, 1)),
	order_payment_method VARCHAR(20),
    service_provider_id INT,
    FOREIGN KEY (shoe_id) REFERENCES [Shoe](id),
    FOREIGN KEY (bill_id) REFERENCES [Bill](id),
    FOREIGN KEY (size_id) REFERENCES [Shoe_Size](id),
    FOREIGN KEY (order_shoe_type) REFERENCES [Order_Shoe_Type](id),
    FOREIGN KEY (order_shoe_status) REFERENCES [Order_Shoe_Status](id),
	FOREIGN KEY (order_payment_method) REFERENCES [Order_Payment_Method](id),
    FOREIGN KEY (service_provider_id) REFERENCES [User](id)
);

CREATE TABLE [Shoe_Extra_Type] (
	id VARCHAR(32) PRIMARY KEY
);

CREATE TABLE [Shoe_Extra] (
	id INT IDENTITY(1,1) PRIMARY KEY,
	title NVARCHAR(750) NOT NULL,
    image_link TEXT,
    date_created DATETIME DEFAULT GETDATE(),
	[description] NVARCHAR(750),
	price float NOT NUll,
	[type] VARCHAR(32) NOT NULL,
	FOREIGN KEY ([type]) REFERENCES [Shoe_Extra_Type](id)
);

CREATE TABLE [Order_Shoe_Extra] (
	id INT IDENTITY(1,1) PRIMARY KEY,
	shoe_extra_id INT NOT NULL,
	order_shoe_id INT NOT NULL,
	FOREIGN KEY (shoe_extra_id) REFERENCES [Shoe_Extra](id),
	FOREIGN KEY (order_shoe_id) REFERENCES [Order_Shoe](id)
);

INSERT INTO [Shoe_Type] VALUES ('low-tops'), ('high-tops'), ('boots'), ('kid-shoes'), ('sandals'), ('others')
INSERT INTO [Shoe_Extra_Type] VALUES ('accessory')
INSERT INTO [Order_Payment_Method] VALUES ('cod'), ('momo')

INSERT INTO [Order_Shoe_Type] VALUES ('in'), ('out')
INSERT INTO [Order_Shoe_Status] VALUES ('pending'), ('cancelled'), ('reverify'), ('in_progress'), ('success')

INSERT INTO [Role] VALUES ('customer', 'Customer', 0), ('service_provider', 'Service Provider', 1), ('admin', 'Admin', 2);
INSERT INTO [User] (username, full_name, email, [password], [address], date_birth, contact_number, city, [state], role_id, token)
VALUES ('thienbao860', N'Từ Thiên Bảo', 'nguyenthienbao860@gmail.com', '12345', N'123 Đường X, Quận Y, TP.HCM', '2003-04-15', '09012345678', N'Ho Chi Minh City', N'Ho Chi Minh', 'admin', 'R3sPvNq2XmH9zWp6Q8LcKlDv7O1eJnY5fT0iAaGyUgSbZw4oF');
INSERT INTO [User] (username, full_name, email, [password], [address], date_birth, contact_number, city, [state], role_id, token)
VALUES ('tanty1234', N'Phạm Tân Tỷ', 'pham_tan_ty@gmail.com', 'StrongPassword456', N'456 Đường Z, Quận W, TP.HCM', '1987-08-28', '09123456789', N'Ho Chi Minh City', N'Ho Chi Minh', 'service_provider', 'W6rPqZjG2vTnLmC5sKx8yOaBz3wHtEi7X1fFpVlDcY9A0uS');
INSERT INTO [User] (username, full_name, email, [password], [address], date_birth, contact_number, city, [state], role_id, token)
VALUES ('minhnhatsmile95', N'Minh Nhật', 'minhnhat95@gmail.com', 'P@ssword3', N'789 Đường C, Quận 3, TP.HCM', '1995-07-10', '07654321098', N'Ho Chi Minh City', N'Ho Chi Minh', 'customer', 'X2oGvNfS4jZyP1q5DcO7bW9sE6KlH0rA3mTtYwL8iVnUgF');
INSERT INTO [User] (username, full_name, email, [password], [address], date_birth, contact_number, city, [state], role_id, token)
VALUES ('admin_quangminh80', N'Quang Minh', 'quangminh80@gmail.com', 'Secret@123', N'101 Đường D, Quận 4, TP.HCM', '1980-12-05', '09321098765', N'Ho Chi Minh City', N'Ho Chi Minh', 'customer', 'Y5fPvHnRw0mK2oZi6aBj9Ux1rL8qT3cS7lDzXgWtE4QyA');
DELETE FROM [Shoe];
DBCC CHECKIDENT ([Shoe], RESEED, 1);

-- High-Tops
INSERT INTO Shoe (title, description, price, shoe_type)
VALUES
('Urban Elegance: High-Top Sneakers', 'Embrace the urban vibe with our high-top sneakers. These shoes are not only stylish but also provide excellent ankle support for your adventures in the city.', 59.99, 'high-tops'),
('Retro Cool: Vintage High-Tops', 'Get a dose of retro cool with these vintage high-top sneakers. Their timeless design and vibrant colors will turn heads wherever you go.', 64.99, 'high-tops'),
('Athletic Performance: High-Top Running Shoes', 'Boost your athletic performance with our high-top running shoes. They offer superior ankle support and cushioning for a more comfortable run.', 69.99, 'high-tops'),
('Classic Revival: Leather High-Top Boots', 'Rediscover the classic appeal with these leather high-top boots. They blend the charm of vintage style with the durability of high-quality leather.', 74.99, 'high-tops');

-- Low-Tops
INSERT INTO Shoe (title, description, price, shoe_type)
VALUES
('Sleek Minimalism: White Canvas Low-Tops', 'Step into style with these white canvas low-top shoes. Perfect for a casual day out or a night on the town. Classic design meets modern comfort.', 49.99, 'low-tops'),
('Casual Elegance: Navy Blue Low-Tops', 'Add a touch of casual elegance to your wardrobe with these navy blue low-top shoes. They''re the perfect blend of style and comfort for any occasion.', 54.99, 'low-tops'),
('Streetwise Chic: Black Leather Low-Tops', 'Step up your streetwise game with these black leather low-top shoes. They offer a sleek and edgy look while keeping your feet comfortable.', 59.99, 'low-tops'),
('Timeless Simplicity: Grey Suede Low-Tops', 'Embrace timeless simplicity with these grey suede low-top shoes. Their soft suede material and minimalist design make them a versatile addition to your wardrobe.', 52.99, 'low-tops');

-- Boots
INSERT INTO Shoe (title, description, price, shoe_type)
VALUES
('Versatile Charm: Brown Leather Boots', 'Discover versatile charm with these brown leather boots. They''re perfect for both casual and semi-formal occasions, combining style and comfort.', 79.99, 'boots'),
('Adventure-Ready: Waterproof Hiking Boots', 'Get adventure-ready with our waterproof hiking boots. They offer excellent traction and durability for your outdoor escapades.', 89.99, 'boots'),
('Winter Warmth: Faux Fur Snow Boots', 'Stay warm in the winter with these faux fur snow boots. Their cozy interior and stylish exterior make them ideal for snowy days.', 69.99, 'boots');

-- Kid Shoes
INSERT INTO Shoe (title, description, price, shoe_type)
VALUES
('Kid''s Delight: Colorful Velcro Shoes', 'Treat your little ones to these colorful Velcro shoes. They''re easy to put on and take off, ensuring a hassle-free experience for both parents and kids.', 29.99, 'kid-shoes'),
('Tiny Explorers: Durable Play Shoes', 'For tiny explorers, we offer these durable play shoes. Let your kids explore the world with confidence in these sturdy and stylish shoes.', 34.99, 'kid-shoes'),
('Fun and Fancy: Sparkling Kids'' Sneakers', 'Add a touch of fun and fancy to your child''s wardrobe with these sparkling kids'' sneakers. They''re perfect for playdates and special occasions.', 39.99, 'kid-shoes');

-- Sandals
INSERT INTO Shoe (title, description, price, shoe_type)
VALUES
('Beach Ready: Comfortable Sandals', 'Get beach-ready with our comfortable sandals. They are designed for relaxation, making them ideal for beach walks, poolside lounging, or a casual stroll.', 34.99, 'sandals'),
('Tropical Paradise: Flip-Flop Sandals', 'Bring the tropical paradise to your feet with these flip-flop sandals. Perfect for a laid-back day at the beach or by the pool.', 19.99, 'sandals'),
('Sunset Vibes: Stylish Beach Sandals', 'Embrace the sunset vibes with our stylish beach sandals. They feature a trendy design, making them the perfect choice for beachside evenings.', 29.99, 'sandals');

UPDATE [Shoe] SET image_link='https://bhnjicatboqdydkqvuui.supabase.co/storage/v1/object/public/shoestylize/shoes/high-tops.jpg' WHERE shoe_type='high-tops'
UPDATE [Shoe] SET image_link='https://bhnjicatboqdydkqvuui.supabase.co/storage/v1/object/public/shoestylize/shoes/low-tops.jpg?t=2023-10-29T23%3A36%3A21.886Z' WHERE shoe_type='low-tops'
UPDATE [Shoe] SET image_link='https://bhnjicatboqdydkqvuui.supabase.co/storage/v1/object/public/shoestylize/shoes/boots.png' WHERE shoe_type='boots'
UPDATE [Shoe] SET image_link='https://bhnjicatboqdydkqvuui.supabase.co/storage/v1/object/public/shoestylize/shoes/kid-shoes.jpg?t=2023-10-29T23%3A36%3A05.152Z' WHERE shoe_type='kid-shoes'
UPDATE [Shoe] SET image_link='https://bhnjicatboqdydkqvuui.supabase.co/storage/v1/object/public/shoestylize/shoes/sandals.jpg?t=2023-10-29T23%3A35%3A56.931Z' WHERE shoe_type='sandals'


INSERT INTO [News](title, content, author_id) VALUES ('Good morning!', 'How it''s going, everyone?', 1)

INSERT INTO [Shoe_Size](id, size_name, [type_id])
VALUES
    (1, '35', 'low-tops'),
    (2, '36', 'low-tops'),
    (3, '37', 'low-tops'),
    (4, '38', 'low-tops'),
    (5, '39', 'low-tops'),
    (6, '40', 'low-tops'),
    (7, '41', 'low-tops'),
    (8, '42', 'low-tops'),
    (9, '43', 'low-tops'),
    (10, '44', 'low-tops'),
    (11, '35', 'high-tops'),
    (12, '36', 'high-tops'),
    (13, '37', 'high-tops'),
    (14, '38', 'high-tops'),
    (15, '39', 'high-tops'),
    (16, '40', 'high-tops'),
    (17, '41', 'high-tops'),
    (18, '42', 'high-tops'),
    (19, '43', 'high-tops'),
    (20, '44', 'high-tops'),
    (21, '35', 'sandals'),
    (22, '36', 'sandals'),
    (23, '37', 'sandals'),
    (24, '38', 'sandals'),
    (25, '39', 'sandals'),
    (26, '40', 'sandals'),
    (27, '41', 'sandals'),
    (28, '42', 'sandals'),
    (29, '43', 'sandals'),
    (30, '44', 'sandals'),
    (31, '35', 'boots'),
    (32, '36', 'boots'),
    (33, '37', 'boots'),
    (34, '38', 'boots'),
    (35, '39', 'boots'),
    (36, '40', 'boots'),
    (37, '41', 'boots'),
    (38, '42', 'boots'),
    (39, '43', 'boots'),
    (40, '44', 'boots'),
    (41, '25', 'kid-shoes'),
    (42, '26', 'kid-shoes'),
    (43, '27', 'kid-shoes'),
    (44, '28', 'kid-shoes'),
    (45, '29', 'kid-shoes'),
    (46, '30', 'kid-shoes'),
    (47, '31', 'kid-shoes'),
    (48, '32', 'kid-shoes'),
    (49, '33', 'kid-shoes'),
    (50, '34', 'kid-shoes');


INSERT INTO Shoe_Extra (title, image_link, [description], price, [type])
VALUES
    ('Shiny Satin Ribbon', 'https://bhnjicatboqdydkqvuui.supabase.co/storage/v1/object/public/shoestylize/accessories/ribbon.jpg?t=2023-10-29T23%3A49%3A57.540Z', 'Add a touch of elegance with this shiny satin ribbon. Available in various colors.', 5.99, 'accessory'),
    ('Leather Laces', 'https://bhnjicatboqdydkqvuui.supabase.co/storage/v1/object/public/shoestylize/accessories/laces.jpg?t=2023-10-29T23%3A50%3A06.434Z', 'Upgrade your shoe''s look with premium leather laces. Available in brown and black.', 8.99, 'accessory'),
    ('Shoe Clips', 'https://bhnjicatboqdydkqvuui.supabase.co/storage/v1/object/public/shoestylize/accessories/clips.jpg?t=2023-10-29T23%3A50%3A13.655Z', 'Make a statement with decorative shoe clips. Choose from a variety of styles.', 6.49, 'accessory'),
    ('Custom Embroidery', 'https://bhnjicatboqdydkqvuui.supabase.co/storage/v1/object/public/shoestylize/accessories/embroidery.jpg?t=2023-10-29T23%3A50%3A49.042Z', 'Personalize your shoes with custom embroidery. Add your initials or a special message.', 12.99, 'accessory'),
    ('Silicone Insole Inserts', 'https://bhnjicatboqdydkqvuui.supabase.co/storage/v1/object/public/shoestylize/accessories/silicone.jpg?t=2023-10-29T23%3A50%3A57.391Z', 'Enhance comfort and support with silicone insole inserts. Perfect for long walks.', 9.99, 'accessory'),
    ('Heel Grips', 'https://bhnjicatboqdydkqvuui.supabase.co/storage/v1/object/public/shoestylize/accessories/heel.jpg?t=2023-10-29T23%3A51%3A08.435Z', 'Prevent blisters and discomfort with these adhesive heel grips. Ideal for high heels.', 4.99, 'accessory'),
    ('LED Light Strips', 'https://bhnjicatboqdydkqvuui.supabase.co/storage/v1/object/public/shoestylize/accessories/led.jpg?t=2023-10-29T23%3A51%3A16.026Z', 'Light up your steps with customizable LED light strips. Change colors and patterns on the go.', 19.99, 'accessory'),
    ('Shoe Cleaning Kit', 'https://bhnjicatboqdydkqvuui.supabase.co/storage/v1/object/public/shoestylize/accessories/kit.jpg?t=2023-10-29T23%3A51%3A25.614Z', 'Keep your shoes looking pristine with a comprehensive shoe cleaning kit.', 14.99, 'accessory');